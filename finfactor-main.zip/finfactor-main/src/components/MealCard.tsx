import Image from 'next/image';
import Link from 'next/link';
import { Meal } from '@/types/meal';

interface MealCardProps {
  meal: Meal;
  className?: string;
}

export default function MealCard({ meal, className = '' }: MealCardProps) {
  return (
    <Link
      href={`/recipe/${meal.idMeal}`}
      className={`group block bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-200 overflow-hidden hover:-translate-y-1 ${className}`}
    >
      <div className="aspect-video relative overflow-hidden">
        <Image
          src={meal.strMealThumb}
          alt={meal.strMeal}
          fill
          className="object-cover transition-transform duration-200 group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          onError={(e) => {
            // Fallback image handling
            const target = e.target as HTMLImageElement;
            target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"%3E%3Crect width="400" height="300" fill="%23e5e7eb"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" fill="%236b7280" font-family="sans-serif" font-size="18"%3ENo Image Available%3C/text%3E%3C/svg%3E';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors duration-200">
          {meal.strMeal}
        </h3>

        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-500">
            {meal.strMeal.length > 30 ? `${meal.strMeal.substring(0, 30)}...` : meal.strMeal}
          </span>

          <div className="flex items-center space-x-1">
            <svg
              className="w-4 h-4 text-gray-400 group-hover:text-blue-500 transition-colors duration-200"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </div>
        </div>
      </div>
    </Link>
  );
}