import Image from 'next/image';
import { FullMeal, IngredientWithMeasure } from '@/types/meal';

interface RecipeDetailsProps {
  meal: FullMeal;
  ingredients: IngredientWithMeasure[];
  className?: string;
}

export default function RecipeDetails({ meal, ingredients, className = '' }: RecipeDetailsProps) {
  const formatInstructions = (instructions: string) => {
    return instructions
      .split(/\r\n|\n|\r/)
      .filter(step => step.trim() !== '')
      .map((step, index) => ({
        number: index + 1,
        text: step.trim()
      }));
  };

  const getYouTubeEmbedUrl = (url: string | null) => {
    if (!url) return null;

    const videoId = url.includes('youtu.be/')
      ? url.split('youtu.be/')[1]?.split('?')[0]
      : url.includes('youtube.com/watch?v=')
      ? url.split('v=')[1]?.split('&')[0]
      : null;

    return videoId ? `https://www.youtube.com/embed/${videoId}` : null;
  };

  const instructions = formatInstructions(meal.strInstructions);
  const embedUrl = getYouTubeEmbedUrl(meal.strYoutube);

  return (
    <div className={`max-w-6xl mx-auto ${className}`}>
      {/* Hero Section */}
      <div className="mb-8">
        <div className="relative aspect-video w-full rounded-2xl overflow-hidden shadow-xl mb-6">
          <Image
            src={meal.strMealThumb}
            alt={meal.strMeal}
            fill
            className="object-cover"
            sizes="(max-width: 1200px) 100vw, 1200px"
            priority
          />
        </div>

        {/* Recipe Title and Metadata */}
        <div className="text-center mb-6">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {meal.strMeal}
          </h1>

          <div className="flex flex-wrap justify-center items-center gap-4 text-sm md:text-base text-gray-600">
            {meal.strCategory && (
              <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full font-medium">
                {meal.strCategory}
              </span>
            )}

            {meal.strArea && (
              <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full font-medium">
                {meal.strArea} Cuisine
              </span>
            )}

            {meal.strTags && (
              <div className="flex flex-wrap gap-2">
                {meal.strTags.split(',').map((tag, index) => (
                  <span
                    key={index}
                    className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-sm"
                  >
                    {tag.trim()}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
        {/* Ingredients Section */}
        <div className="bg-white rounded-xl shadow-md p-6 lg:sticky lg:top-6 lg:h-fit">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <svg
              className="w-6 h-6 mr-3 text-blue-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
              />
            </svg>
            Ingredients
          </h2>

          <div className="space-y-3">
            {ingredients.map((item, index) => (
              <div
                key={index}
                className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-150"
              >
                <div className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <span className="font-medium text-gray-900">
                    {item.ingredient}
                  </span>
                  {item.measure && (
                    <span className="text-gray-600 ml-2">
                      - {item.measure}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {ingredients.length === 0 && (
            <p className="text-gray-500 text-center py-8">
              No ingredients available for this recipe.
            </p>
          )}
        </div>

        {/* Instructions Section */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <svg
              className="w-6 h-6 mr-3 text-green-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
              />
            </svg>
            Instructions
          </h2>

          <div className="space-y-4">
            {instructions.map((step) => (
              <div
                key={step.number}
                className="flex items-start space-x-4 p-4 rounded-lg hover:bg-gray-50 transition-colors duration-150"
              >
                <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">
                  {step.number}
                </div>
                <p className="text-gray-700 leading-relaxed flex-1">
                  {step.text}
                </p>
              </div>
            ))}
          </div>

          {instructions.length === 0 && (
            <p className="text-gray-500 text-center py-8">
              No instructions available for this recipe.
            </p>
          )}
        </div>
      </div>

      {/* YouTube Video */}
      {embedUrl && (
        <div className="mt-12 bg-white rounded-xl shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
            <svg
              className="w-6 h-6 mr-3 text-red-500"
              fill="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
            </svg>
            Video Tutorial
          </h3>
          <div className="aspect-video w-full rounded-lg overflow-hidden">
            <iframe
              src={embedUrl}
              title={`${meal.strMeal} - Video Tutorial`}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>
      )}

      {/* Additional Info */}
      {meal.strSource && (
        <div className="mt-8 text-center">
          <a
            href={meal.strSource}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center text-blue-500 hover:text-blue-600 transition-colors duration-200"
          >
            <svg
              className="w-5 h-5 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"
              />
            </svg>
            View Original Source
          </a>
        </div>
      )}
    </div>
  );
}