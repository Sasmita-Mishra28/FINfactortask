import { ApiResponse, Category, Meal, FullMeal, Ingredient, ApiError } from '@/types/meal';

const THE_MEAL_DB_BASE_URL = 'https://www.themealdb.com/api/json/v1/1';

class TheMealDBApiError extends Error {
  constructor(
    message: string,
    public status?: number,
    public code?: string
  ) {
    super(message);
    this.name = 'TheMealDBApiError';
  }
}

class TheMealDBClient {
  private baseUrl: string;

  constructor(baseUrl: string = THE_MEAL_DB_BASE_URL) {
    this.baseUrl = baseUrl;
  }

  private async fetchFromApi<T>(endpoint: string): Promise<T> {
    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
        },
        signal: AbortSignal.timeout(10000), // 10 second timeout
      });

      if (!response.ok) {
        throw new TheMealDBApiError(
          `HTTP error! status: ${response.status}`,
          response.status
        );
      }

      const data: T = await response.json();
      return data;
    } catch (error) {
      if (error instanceof TheMealDBApiError) {
        throw error;
      }

      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw new TheMealDBApiError('Request timeout', 408, 'TIMEOUT');
        }

        if (error.message.includes('ENOTFOUND') || error.message.includes('ETIMEDOUT')) {
          throw new TheMealDBApiError('TheMealDB service unavailable', 503, 'SERVICE_UNAVAILABLE');
        }

        throw new TheMealDBApiError(`Network error: ${error.message}`, 500, 'NETWORK_ERROR');
      }

      throw new TheMealDBApiError('Unknown error occurred', 500, 'UNKNOWN_ERROR');
    }
  }

  /**
   * Get all meal categories
   */
  async getCategories(): Promise<Category[]> {
    const response: ApiResponse<Category> = await this.fetchFromApi('/categories.php');
    return response.categories || [];
  }

  /**
   * Filter meals by category
   */
  async getMealsByCategory(category: string): Promise<Meal[]> {
    if (!category || category.trim() === '') {
      throw new TheMealDBApiError('Category parameter is required', 400, 'INVALID_CATEGORY');
    }

    const response: ApiResponse<Meal> = await this.fetchFromApi(`/filter.php?c=${encodeURIComponent(category.trim())}`);
    return response.meals || [];
  }

  /**
   * Search meals by name
   */
  async searchMealsByName(query: string): Promise<Meal[]> {
    if (!query || query.trim() === '') {
      throw new TheMealDBApiError('Search query is required', 400, 'INVALID_QUERY');
    }

    const response: ApiResponse<Meal> = await this.fetchFromApi(`/search.php?s=${encodeURIComponent(query.trim())}`);
    return response.meals || [];
  }

  /**
   * Search meals by first letter
   */
  async searchMealsByFirstLetter(letter: string): Promise<Meal[]> {
    if (!letter || letter.trim() === '' || letter.trim().length !== 1) {
      throw new TheMealDBApiError('First letter parameter must be a single character', 400, 'INVALID_LETTER');
    }

    const response: ApiResponse<Meal> = await this.fetchFromApi(`/search.php?f=${encodeURIComponent(letter.trim().charAt(0))}`);
    return response.meals || [];
  }

  /**
   * Lookup meal details by ID
   */
  async getMealById(id: string): Promise<FullMeal | null> {
    if (!id || id.trim() === '') {
      throw new TheMealDBApiError('Meal ID is required', 400, 'INVALID_MEAL_ID');
    }

    const response: ApiResponse<FullMeal> = await this.fetchFromApi(`/lookup.php?i=${encodeURIComponent(id.trim())}`);
    return response.meals?.[0] || null;
  }

  /**
   * Get a random meal
   */
  async getRandomMeal(): Promise<FullMeal | null> {
    const response: ApiResponse<FullMeal> = await this.fetchFromApi('/random.php');
    return response.meals?.[0] || null;
  }

  /**
   * Get multiple random meals
   */
  async getRandomMeals(count: number): Promise<FullMeal[]> {
    if (count < 1 || count > 10) {
      throw new TheMealDBApiError('Count must be between 1 and 10', 400, 'INVALID_COUNT');
    }

    const promises = Array.from({ length: count }, () => this.getRandomMeal());
    const meals = await Promise.all(promises);
    return meals.filter((meal): meal is FullMeal => meal !== null);
  }

  /**
   * List all ingredients
   */
  async getIngredients(): Promise<Ingredient[]> {
    const response: ApiResponse<Ingredient> = await this.fetchFromApi('/list.php?i=list');
    return response.ingredients || [];
  }

  /**
   * Filter meals by main ingredient
   */
  async getMealsByIngredient(ingredient: string): Promise<Meal[]> {
    if (!ingredient || ingredient.trim() === '') {
      throw new TheMealDBApiError('Ingredient parameter is required', 400, 'INVALID_INGREDIENT');
    }

    const response: ApiResponse<Meal> = await this.fetchFromApi(`/filter.php?i=${encodeURIComponent(ingredient.trim())}`);
    return response.meals || [];
  }
}

// Create singleton instance
const themealdbClient = new TheMealDBClient();

export { themealdbClient, TheMealDBApiError };
export default themealdbClient;