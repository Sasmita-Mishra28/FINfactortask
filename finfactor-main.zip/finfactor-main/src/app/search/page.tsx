'use client';

import { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import MealCard from '@/components/MealCard';
import SearchBar from '@/components/SearchBar';
import { Meal } from '@/types/meal';

export default function SearchPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const initialQuery = searchParams.get('q') || '';
  const initialLetter = searchParams.get('f') || '';

  const [query, setQuery] = useState(initialQuery);
  const [letter, setLetter] = useState(initialLetter);
  const [meals, setMeals] = useState<Meal[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchType, setSearchType] = useState<'name' | 'letter'>(
    initialQuery ? 'name' : initialLetter ? 'letter' : 'name'
  );

  useEffect(() => {
    async function performSearch() {
      const searchQuery = query.trim();
      const searchLetter = letter.trim();

      if (!searchQuery && !searchLetter) {
        setMeals([]);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        let searchUrl = '';
        if (searchQuery) {
          searchUrl = `/api/search?q=${encodeURIComponent(searchQuery)}`;
        } else if (searchLetter) {
          searchUrl = `/api/search?f=${encodeURIComponent(searchLetter)}`;
        }

        const response = await fetch(searchUrl);
        if (!response.ok) {
          if (response.status === 400) {
            throw new Error('Invalid search parameters');
          }
          throw new Error('Failed to perform search');
        }

        const data = await response.json();
        setMeals(data.meals || []);
      } catch (err) {
        console.error('Error searching meals:', err);
        setError(err instanceof Error ? err.message : 'An error occurred');
        setMeals([]);
      } finally {
        setLoading(false);
      }
    }

    if (initialQuery || initialLetter) {
      performSearch();
    }
  }, [initialQuery, initialLetter]);

  const handleSearch = (searchQuery: string) => {
    setQuery(searchQuery);
    setLetter('');
    setSearchType('name');

    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      router.push('/search');
    }
  };

  const handleLetterSearch = (selectedLetter: string) => {
    setLetter(selectedLetter);
    setQuery('');
    setSearchType('letter');
    router.push(`/search?f=${encodeURIComponent(selectedLetter)}`);
  };

  const getSearchInfo = () => {
    if (searchType === 'name' && query) {
      return {
        title: `Search Results for "${query}"`,
        description: `Found ${meals.length} recipe${meals.length !== 1 ? 's' : ''} matching "${query}"`,
      };
    }
    if (searchType === 'letter' && letter) {
      return {
        title: `Recipes Starting with "${letter.toUpperCase()}"`,
        description: `Found ${meals.length} recipe${meals.length !== 1 ? 's' : ''} starting with the letter ${letter.toUpperCase()}`,
      };
    }
    return {
      title: 'Search Recipes',
      description: 'Find your next favorite recipe by name or browse by first letter',
    };
  };

  const searchInfo = getSearchInfo();
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  const SkeletonCard = () => (
    <div className="bg-gray-100 rounded-lg animate-pulse">
      <div className="aspect-video bg-gray-200 rounded-t-lg" />
      <div className="p-4">
        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
        <div className="h-3 bg-gray-200 rounded w-1/2" />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <nav className="flex items-center space-x-4 text-sm">
            <Link href="/" className="text-gray-500 hover:text-gray-700">
              Home
            </Link>
            <span className="text-gray-300">/</span>
            <span className="text-gray-900 font-medium">Search</span>
          </nav>
        </div>
      </div>

      {/* Search Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white py-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Search Recipes
          </h1>
          <p className="text-xl mb-8 opacity-90">
            Find your next favorite recipe by name or browse by first letter
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-8">
            <SearchBar
              placeholder="Search for meals, ingredients..."
              defaultValue={query}
              showSuggestions={true}
            />
          </div>

          {/* Letter Search */}
          <div className="mb-8">
            <h3 className="text-lg font-medium mb-4 opacity-90">Or browse by first letter:</h3>
            <div className="flex flex-wrap justify-center gap-2">
              {alphabet.map((l) => (
                <button
                  key={l}
                  onClick={() => handleLetterSearch(l)}
                  className={`w-10 h-10 rounded-lg font-medium transition-all ${
                    letter === l
                      ? 'bg-white text-purple-700'
                      : 'bg-purple-500 text-white hover:bg-purple-400'
                  }`}
                  aria-label={`Search recipes starting with ${l}`}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Search Info */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {searchInfo.title}
          </h2>
          <p className="text-gray-600">{searchInfo.description}</p>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(12)].map((_, index) => (
              <SkeletonCard key={index} />
            ))}
          </div>
        )}

        {/* Error State */}
        {error && !loading && (
          <div className="text-center py-12">
            <div className="text-red-500 mb-4">
              <svg
                className="w-16 h-16 mx-auto"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">
              Search Error
            </h3>
            <p className="text-gray-600 mb-4">{error}</p>
            <Link
              href="/"
              className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              Back to Home
            </Link>
          </div>
        )}

        {/* No Results */}
        {!loading && !error && meals.length === 0 && (query || letter) && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <svg
                className="w-16 h-16 mx-auto"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">
              No recipes found
            </h3>
            <p className="text-gray-600 mb-6">
              {searchType === 'name'
                ? `We couldn't find any recipes matching "${query}". Try different keywords or browse by letter.`
                : `We couldn't find any recipes starting with "${letter.toUpperCase()}". Try a different letter.`
              }
            </p>
            <div className="flex justify-center space-x-4">
              <Link
                href="/categories"
                className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                Browse Categories
              </Link>
              <button
                onClick={() => router.push('/search')}
                className="inline-flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Clear Search
              </button>
            </div>
          </div>
        )}

        {/* Search Results */}
        {!loading && !error && meals.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {meals.map((meal) => (
              <MealCard key={meal.idMeal} meal={meal} />
            ))}
          </div>
        )}

        {/* Initial State */}
        {!loading && !error && meals.length === 0 && !query && !letter && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <svg
                className="w-16 h-16 mx-auto"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">
              Start Searching
            </h3>
            <p className="text-gray-600 mb-6">
              Enter a recipe name above or click on a letter to browse recipes by first letter.
            </p>
            <div className="flex justify-center space-x-4">
              <Link
                href="/categories"
                className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                Browse Categories
              </Link>
              <Link
                href="/"
                className="inline-flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Back to Home
              </Link>
            </div>
          </div>
        )}
      </div>

      {/* Popular Searches */}
      <div className="bg-white py-12 px-4 border-t">
        <div className="max-w-7xl mx-auto">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Popular Searches</h3>
          <div className="flex flex-wrap gap-3">
            {['Chicken', 'Pasta', 'Salad', 'Dessert', 'Soup', 'Cake', 'Beef', 'Seafood'].map((term) => (
              <button
                key={term}
                onClick={() => handleSearch(term)}
                className="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200 transition-colors"
              >
                {term}
                <svg
                  className="w-4 h-4 ml-1"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}