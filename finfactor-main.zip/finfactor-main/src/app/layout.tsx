import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "TheMealDB Explorer - Discover Amazing Recipes",
  description: "Explore thousands of delicious recipes from around the world. Browse by category, search for specific meals, and get detailed cooking instructions with ingredients and step-by-step guides.",
  keywords: ["recipes", "cooking", "meals", "food", "cuisine", "ingredients", "TheMealDB"],
  authors: [{ name: "TheMealDB Explorer" }],
  openGraph: {
    title: "TheMealDB Explorer - Discover Amazing Recipes",
    description: "Explore thousands of delicious recipes from around the world",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "TheMealDB Explorer",
    description: "Discover delicious recipes from around the world",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
