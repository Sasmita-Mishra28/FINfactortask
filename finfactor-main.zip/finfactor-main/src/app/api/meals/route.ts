import { NextRequest, NextResponse } from 'next/server';
import themealdbClient, { TheMealDBApiError } from '@/lib/themealdb';
import cache, { CACHE_DURATIONS } from '@/lib/cache';
import { ApiError } from '@/types/meal';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');

    // Validate required parameter
    if (!category || category.trim() === '') {
      const errorResponse: ApiError = {
        error: 'Category parameter is required',
        code: 'INVALID_CATEGORY',
        timestamp: new Date().toISOString(),
      };

      return NextResponse.json(errorResponse, {
        status: 400,
      });
    }

    const normalizedCategory = category.trim();
    const cacheKey = `meals:${normalizedCategory}`;

    // Check cache first
    const cachedData = cache.get(cacheKey);
    if (cachedData) {
      return NextResponse.json(cachedData, {
        status: 200,
        headers: {
          'X-Cache': 'HIT',
        },
      });
    }

    // Fetch from TheMealDB API
    const meals = await themealdbClient.getMealsByCategory(normalizedCategory);

    const responseData = {
      category: normalizedCategory,
      meals,
      count: meals.length,
      timestamp: new Date().toISOString(),
    };

    // Store in cache
    cache.set(cacheKey, responseData, CACHE_DURATIONS.MEAL_LISTS);

    return NextResponse.json(responseData, {
      status: 200,
      headers: {
        'X-Cache': 'MISS',
      },
    });
  } catch (error) {
    console.error('Error fetching meals by category:', error);

    if (error instanceof TheMealDBApiError) {
      const errorResponse: ApiError = {
        error: error.message,
        code: error.code || 'API_ERROR',
        timestamp: new Date().toISOString(),
      };

      return NextResponse.json(errorResponse, {
        status: error.status || 500,
      });
    }

    const errorResponse: ApiError = {
      error: 'Failed to fetch meals',
      code: 'INTERNAL_SERVER_ERROR',
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(errorResponse, {
      status: 500,
    });
  }
}