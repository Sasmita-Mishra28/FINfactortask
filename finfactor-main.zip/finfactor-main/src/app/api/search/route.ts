import { NextRequest, NextResponse } from 'next/server';
import themealdbClient, { TheMealDBApiError } from '@/lib/themealdb';
import cache, { CACHE_DURATIONS } from '@/lib/cache';
import { ApiError, Meal } from '@/types/meal';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');
    const firstLetter = searchParams.get('f');

    // Validate that at least one search parameter is provided
    if ((!query || query.trim() === '') && (!firstLetter || firstLetter.trim() === '')) {
      const errorResponse: ApiError = {
        error: 'At least one search parameter (q or f) is required',
        code: 'INVALID_SEARCH_PARAMS',
        timestamp: new Date().toISOString(),
      };

      return NextResponse.json(errorResponse, {
        status: 400,
      });
    }

    let meals: Meal[] = [];
    let searchType = '';
    let searchValue = '';

    // Perform search by name if query is provided
    if (query && query.trim() !== '') {
      searchType = 'name';
      searchValue = query.trim();
      const cacheKey = `search:name:${searchValue.toLowerCase()}`;

      // Check cache first
      const cachedData = cache.get(cacheKey);
      if (cachedData) {
        return NextResponse.json(cachedData, {
          status: 200,
          headers: {
            'X-Cache': 'HIT',
          },
        });
      }

      meals = await themealdbClient.searchMealsByName(searchValue);

      const responseData = {
        searchType,
        query: searchValue,
        meals,
        count: meals.length,
        timestamp: new Date().toISOString(),
      };

      // Store in cache
      cache.set(cacheKey, responseData, CACHE_DURATIONS.SEARCH_RESULTS);

      return NextResponse.json(responseData, {
        status: 200,
        headers: {
          'X-Cache': 'MISS',
        },
      });
    }

    // Perform search by first letter if firstLetter is provided
    if (firstLetter && firstLetter.trim() !== '') {
      searchType = 'letter';
      searchValue = firstLetter.trim().charAt(0).toLowerCase();
      const cacheKey = `search:letter:${searchValue}`;

      // Check cache first
      const cachedData = cache.get(cacheKey);
      if (cachedData) {
        return NextResponse.json(cachedData, {
          status: 200,
          headers: {
            'X-Cache': 'HIT',
          },
        });
      }

      meals = await themealdbClient.searchMealsByFirstLetter(searchValue);

      const responseData = {
        searchType,
        query: searchValue,
        meals,
        count: meals.length,
        timestamp: new Date().toISOString(),
      };

      // Store in cache
      cache.set(cacheKey, responseData, CACHE_DURATIONS.SEARCH_RESULTS);

      return NextResponse.json(responseData, {
        status: 200,
        headers: {
          'X-Cache': 'MISS',
        },
      });
    }

    // This should not be reached due to validation above
    const errorResponse: ApiError = {
      error: 'Invalid search parameters',
      code: 'INVALID_SEARCH_PARAMS',
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(errorResponse, {
      status: 400,
    });
  } catch (error) {
    console.error('Error searching meals:', error);

    if (error instanceof TheMealDBApiError) {
      const errorResponse: ApiError = {
        error: error.message,
        code: error.code || 'API_ERROR',
        timestamp: new Date().toISOString(),
      };

      return NextResponse.json(errorResponse, {
        status: error.status || 500,
      });
    }

    const errorResponse: ApiError = {
      error: 'Failed to search meals',
      code: 'INTERNAL_SERVER_ERROR',
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(errorResponse, {
      status: 500,
    });
  }
}