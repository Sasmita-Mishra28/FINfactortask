import { NextRequest, NextResponse } from 'next/server';
import themealdbClient, { TheMealDBApiError } from '@/lib/themealdb';
import cache, { CACHE_DURATIONS } from '@/lib/cache';
import { ApiError, FullMeal, IngredientWithMeasure } from '@/types/meal';

function extractIngredients(meal: FullMeal): IngredientWithMeasure[] {
  const ingredients: IngredientWithMeasure[] = [];

  for (let i = 1; i <= 20; i++) {
    const ingredient = meal[`strIngredient${i}` as keyof FullMeal] as string | null;
    const measure = meal[`strMeasure${i}` as keyof FullMeal] as string | null;

    if (ingredient && ingredient.trim() !== '') {
      ingredients.push({
        ingredient: ingredient.trim(),
        measure: measure?.trim() || '',
      });
    }
  }

  return ingredients;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: mealId } = await params;

    // Validate meal ID
    if (!mealId || mealId.trim() === '') {
      const errorResponse: ApiError = {
        error: 'Meal ID is required',
        code: 'INVALID_MEAL_ID',
        timestamp: new Date().toISOString(),
      };

      return NextResponse.json(errorResponse, {
        status: 400,
      });
    }

    const normalizedId = mealId.trim();
    const cacheKey = `recipe:${normalizedId}`;

    // Check cache first
    const cachedData = cache.get(cacheKey);
    if (cachedData) {
      return NextResponse.json(cachedData, {
        status: 200,
        headers: {
          'X-Cache': 'HIT',
        },
      });
    }

    // Fetch from TheMealDB API
    const meal = await themealdbClient.getMealById(normalizedId);

    if (!meal) {
      const errorResponse: ApiError = {
        error: 'Meal not found',
        code: 'MEAL_NOT_FOUND',
        timestamp: new Date().toISOString(),
      };

      return NextResponse.json(errorResponse, {
        status: 404,
      });
    }

    // Extract ingredients and measurements
    const ingredients = extractIngredients(meal);

    const responseData = {
      meal: {
        ...meal,
        ingredients,
      },
      timestamp: new Date().toISOString(),
    };

    // Store in cache
    cache.set(cacheKey, responseData, CACHE_DURATIONS.RECIPE_DETAILS);

    return NextResponse.json(responseData, {
      status: 200,
      headers: {
        'X-Cache': 'MISS',
      },
    });
  } catch (error) {
    console.error('Error fetching recipe details:', error);

    if (error instanceof TheMealDBApiError) {
      const errorResponse: ApiError = {
        error: error.message,
        code: error.code || 'API_ERROR',
        timestamp: new Date().toISOString(),
      };

      return NextResponse.json(errorResponse, {
        status: error.status || 500,
      });
    }

    const errorResponse: ApiError = {
      error: 'Failed to fetch recipe details',
      code: 'INTERNAL_SERVER_ERROR',
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(errorResponse, {
      status: 500,
    });
  }
}