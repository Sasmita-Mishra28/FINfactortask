import { NextRequest, NextResponse } from 'next/server';
import themealdbClient, { TheMealDBApiError } from '@/lib/themealdb';
import cache, { CACHE_DURATIONS } from '@/lib/cache';
import { ApiError, FullMeal } from '@/types/meal';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const countParam = searchParams.get('count');

    // Default count is 1
    let count = 1;

    if (countParam) {
      const parsedCount = parseInt(countParam, 10);

      // Validate count parameter
      if (isNaN(parsedCount) || parsedCount < 1 || parsedCount > 10) {
        const errorResponse: ApiError = {
          error: 'Count parameter must be a number between 1 and 10',
          code: 'INVALID_COUNT',
          timestamp: new Date().toISOString(),
        };

        return NextResponse.json(errorResponse, {
          status: 400,
        });
      }

      count = parsedCount;
    }

    const cacheKey = `random:${count}`;

    // Check cache first
    const cachedData = cache.get(cacheKey);
    if (cachedData) {
      return NextResponse.json(cachedData, {
        status: 200,
        headers: {
          'X-Cache': 'HIT',
        },
      });
    }

    // Fetch from TheMealDB API
    const meals = await themealdbClient.getRandomMeals(count);

    const responseData = {
      meals,
      count: meals.length,
      requestedCount: count,
      timestamp: new Date().toISOString(),
    };

    // Store in cache
    cache.set(cacheKey, responseData, CACHE_DURATIONS.RANDOM_MEALS);

    return NextResponse.json(responseData, {
      status: 200,
      headers: {
        'X-Cache': 'MISS',
      },
    });
  } catch (error) {
    console.error('Error fetching random meals:', error);

    if (error instanceof TheMealDBApiError) {
      const errorResponse: ApiError = {
        error: error.message,
        code: error.code || 'API_ERROR',
        timestamp: new Date().toISOString(),
      };

      return NextResponse.json(errorResponse, {
        status: error.status || 500,
      });
    }

    const errorResponse: ApiError = {
      error: 'Failed to fetch random meals',
      code: 'INTERNAL_SERVER_ERROR',
      timestamp: new Date().toISOString(),
    };

    return NextResponse.json(errorResponse, {
      status: 500,
    });
  }
}